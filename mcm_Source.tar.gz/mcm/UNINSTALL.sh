sudo rm /usr/bin/mcm
rm ~/.local/share/applications/mcm.desktop
rm -R ~/.mcm/
rm ~/Escritorio/mcm.desktop
sudo rm /usr/share/applications/mcm.desktop
sudo rm /usr/bin/UNINSTALL_mcm.sh
rm ~/Escritorio/mcm_Uninstall.desktop
sudo rm /usr/share/applications/mcm_Uninstall.desktop
sudo rm /usr/share/pixmaps/mcm.png
