#include <stdio.h>

void hola(){

	system("clear");

	printf("\x1B[34m \n				======================================");
	printf("\n				*                                    *\n				* Escrito por Pablo Jimenez Rebollo. *\n				*     Numero de matricula 15782.     *\n				*    Grado en Ingenieria Quimica.    *\n				*                                    *\n");
	printf("				======================================\n\x1B[0m");

}
