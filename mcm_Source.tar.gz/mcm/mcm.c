#include <stdio.h>
#include <stdlib.h>
#include </opt/mcm/ejecucion.h>
#include </opt/mcm/hola.h>
#include </opt/mcm/adios.h>

int main(){

	hola();

	printf("\nPrograma que calcula el minimo comun multiplo de un grupo de numeros dado");

	ejecucion();

	adios();

	return 0;

}
